package com.cognizant.skilltracker.service;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class FseProfileServiceTest {

    @BeforeEach
    void setUp() {
    }

    @Test
    void addProfile() {
    }

    @Test
    void getProfile() {
    }

    @Test
    void updateProfile() {
    }

    @Test
    void getProfiles() {
    }
}