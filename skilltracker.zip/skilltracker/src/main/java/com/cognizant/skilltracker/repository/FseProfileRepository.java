package com.cognizant.skilltracker.repository;

import java.util.List;

import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.data.mongodb.repository.Query;
import org.springframework.stereotype.Repository;

import com.cognizant.skilltracker.document.FseDocument;

@Repository
public interface FseProfileRepository extends MongoRepository<FseDocument, String> {

	@Query("{$or :[{name:{$regex:?0}},{id: ?1},{skills:{$elemMatch:{skill:?2}}}]} ") 
	List<FseDocument> getFseDocumentByCriteria(String name, String id, String skill);

}
