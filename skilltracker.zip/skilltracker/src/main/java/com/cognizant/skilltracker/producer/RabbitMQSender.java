package com.cognizant.skilltracker.producer;

import org.springframework.amqp.core.AmqpTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import com.cognizant.skilltracker.document.FseDocument;
import com.cognizant.skilltracker.model.FseProfile;


@Service
public class RabbitMQSender {
	
	@Autowired
	private AmqpTemplate rabbitTemplate;
	
	@Value("${cts.rabbitmq.exchange}")
	private String exchange;
	
	@Value("${cts.rabbitmq.routingkey}")
	private String routingkey;
	
	public void send(FseDocument document) {
		rabbitTemplate.convertAndSend(exchange, routingkey, document);
		System.out.println("Send msg = " + document);
	    
	}
}

